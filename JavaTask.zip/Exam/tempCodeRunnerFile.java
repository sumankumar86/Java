
        char[] array = line.toCharArray();
        String sentence = "";
        for(int i=0;i<array.length;i++){